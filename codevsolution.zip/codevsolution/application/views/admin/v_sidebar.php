<div class="inner-wrapper">
				<!-- start: sidebar -->
				<aside id="sidebar-left" class="sidebar-left">
				
				<div class="sidebar-header">
					<div class="sidebar-title">
						Navigation
					</div>
					<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
						<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
					</div>
				</div>
			
				<div class="nano">
					<div class="nano-content">
						<nav id="menu" class="nav-main" role="navigation">
							<ul class="nav nav-main">
								<li class="nav-active">
									<a href="<?php echo base_url('Dashboard'); ?>">
										<i class="fa fa-home" aria-hidden="true"></i>
										<span>Dashboard</span>
									</a>
								</li>
								<li>
									<a href="mailbox-folder.html">
										<span class="pull-right label label-primary">Gallery</span>
										<i class="fa fa-envelope" aria-hidden="true"></i>
										<span>Mailbox</span>
									</a>
								</li>
								<li class="nav-parent">
									<a>
										<i class="fa fa-copy" aria-hidden="true"></i>
										<span>Post Berita</span>
									</a>
									<ul class="nav nav-children">
										<li>
											<a href="pages-signup.html">
												 Add New Berita
											</a>
										</li>
										<li>
											<a href="pages-signin.html">
												 Data Berita
											</a>
										</li>
										<li>
											<a href="pages-recover-password.html">
												 Kategori Berita
											</a>
										</li>
									
									</ul>
								</li>
								<li class="nav-parent">
									<a>
										<i class="fa fa-tasks" aria-hidden="true"></i>
										<span>Inbox</span>
									</a>
									<ul class="nav nav-children">
										<li>
											<a href="ui-elements-typography.html">
												 Data Inbox
											</a>
										</li>
									
									</ul>
								</li>
								<li class="nav-parent">
									<a>
										<i class="fa fa-list-alt" aria-hidden="true"></i>
										<span>Data Pengguna</span>
									</a>
									<ul class="nav nav-children">
										<li>
											<a href="forms-basic.html">
												 Data Pengguna
											</a>
										</li>
										
									</ul>
								</li>
								
							</ul>
						</nav>
			
						<hr class="separator" />
			
						
		
					</div>
			
				</div>
			
			</aside>
				<!-- end: sidebar -->